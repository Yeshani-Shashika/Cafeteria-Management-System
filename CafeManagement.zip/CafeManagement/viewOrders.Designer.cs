﻿
namespace CafeManagement
{
    partial class viewOrders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.CategoryTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ViewOrdersReport = new CafeManagement.ViewOrdersReport();
            this.label7 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.itemDGV = new System.Windows.Forms.DataGridView();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.CategoryTblTableAdapter = new CafeManagement.ViewOrdersReportTableAdapters.CategoryTblTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.CategoryTblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ViewOrdersReport)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // CategoryTblBindingSource
            // 
            this.CategoryTblBindingSource.DataMember = "CategoryTbl";
            this.CategoryTblBindingSource.DataSource = this.ViewOrdersReport;
            // 
            // ViewOrdersReport
            // 
            this.ViewOrdersReport.DataSetName = "ViewOrdersReport";
            this.ViewOrdersReport.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(233, 21);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(111, 25);
            this.label7.TabIndex = 21;
            this.label7.Text = "Order List";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.button4.Location = new System.Drawing.Point(231, 542);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(108, 31);
            this.button4.TabIndex = 19;
            this.button4.Text = "Back";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // itemDGV
            // 
            this.itemDGV.BackgroundColor = System.Drawing.Color.White;
            this.itemDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.itemDGV.Location = new System.Drawing.Point(23, 48);
            this.itemDGV.Margin = new System.Windows.Forms.Padding(2);
            this.itemDGV.Name = "itemDGV";
            this.itemDGV.RowHeadersWidth = 51;
            this.itemDGV.RowTemplate.Height = 24;
            this.itemDGV.Size = new System.Drawing.Size(548, 467);
            this.itemDGV.TabIndex = 22;
            this.itemDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.itemDGV_CellContentClick);
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.CategoryTblBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "CafeManagement.CategoryReport.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(33, 247);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.ServerReport.BearerToken = null;
            this.reportViewer1.Size = new System.Drawing.Size(428, 254);
            this.reportViewer1.TabIndex = 23;
            // 
            // CategoryTblTableAdapter
            // 
            this.CategoryTblTableAdapter.ClearBeforeFill = true;
            // 
            // viewOrders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(600, 592);
            this.Controls.Add(this.reportViewer1);
            this.Controls.Add(this.itemDGV);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label7);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "viewOrders";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "viewOrders";
            this.Load += new System.EventHandler(this.viewOrders_Load);
            ((System.ComponentModel.ISupportInitialize)(this.CategoryTblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ViewOrdersReport)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DataGridView itemDGV;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource CategoryTblBindingSource;
        private ViewOrdersReport ViewOrdersReport;
        private ViewOrdersReportTableAdapters.CategoryTblTableAdapter CategoryTblTableAdapter;
    }
}