CREATE DATABASE CafeManagementSystem;

CREATE TABLE [dbo].[ItemTbl] (
    [Id]      INT        IDENTITY (1, 1) NOT NULL,
    [itName]  NCHAR (50) NOT NULL,
    [itcat]  NCHAR (50) NOT NULL,
    [itPrice] INT        NOT NULL,
    [itQty]  NCHAR (10) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);
 

CREATE TABLE [dbo].[CategoryTbl] (
    [catId]  INT        IDENTITY (1, 1) NOT NULL,
    [catName] NCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([catId] ASC)
);

CREATE TABLE [dbo].[OrderTbl] (
    [ordId]    INT  IDENTITY (1, 1) NOT NULL,
    [ordDate]  DATE NOT NULL,
    [ordAmount] INT  NOT NULL,
    PRIMARY KEY CLUSTERED ([ordId] ASC)
);

SELECT * FROM [dbo].[ItemTbl];
SELECT * FROM [dbo].[CategoryTbl]; 
SELECT * FROM [dbo].[OrderTbl];
